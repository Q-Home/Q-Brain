import"./Bzak7iHL.js";import"./CgdfCFx4.js";import{aw as u,f as $,g as m,B as M}from"./BaEqmHSu.js";import{I as f,s as g}from"./B23e1j6b.js";import{l as h,s as _}from"./CjUDN5cm.js";import{f as T,b as y,c as I,s as z,d as F}from"./jbWywkKa.js";import{g as v}from"./CxZYA46j.js";function X(e,t){const s=h(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.509.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const a=[["path",{d:"M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z"}],["path",{d:"M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z"}],["path",{d:"M15 13a4.5 4.5 0 0 1-3-4 4.5 4.5 0 0 1-3 4"}],["path",{d:"M17.599 6.5a3 3 0 0 0 .399-1.375"}],["path",{d:"M6.003 5.125A3 3 0 0 0 6.401 6.5"}],["path",{d:"M3.477 10.896a4 4 0 0 1 .585-.396"}],["path",{d:"M19.938 10.5a4 4 0 0 1 .585.396"}],["path",{d:"M6 18a4 4 0 0 1-1.967-.516"}],["path",{d:"M19.967 17.484A4 4 0 0 1 18 18"}]];f(e,_({name:"brain"},()=>s,{get iconNode(){return a},children:(n,o)=>{var r=u(),i=$(r);g(i,t,"default",{},null),m(n,r)},$$slots:{default:!0}}))}function Z(e,t){const s=h(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.509.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const a=[["path",{d:"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"}],["path",{d:"M13 8H7"}],["path",{d:"M17 12H7"}]];f(e,_({name:"message-square-text"},()=>s,{get iconNode(){return a},children:(n,o)=>{var r=u(),i=$(r);g(i,t,"default",{},null),m(n,r)},$$slots:{default:!0}}))}function j(e,t){const s=h(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.509.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const a=[["path",{d:"M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"}],["path",{d:"m15 5 4 4"}]];f(e,_({name:"pencil"},()=>s,{get iconNode(){return a},children:(n,o)=>{var r=u(),i=$(r);g(i,t,"default",{},null),m(n,r)},$$slots:{default:!0}}))}function k(e,t){const s=h(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.509.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const a=[["path",{d:"M20 7h-9"}],["path",{d:"M14 17H5"}],["circle",{cx:"17",cy:"17",r:"3"}],["circle",{cx:"7",cy:"7",r:"3"}]];f(e,_({name:"settings-2"},()=>s,{get iconNode(){return a},children:(n,o)=>{var r=u(),i=$(r);g(i,t,"default",{},null),m(n,r)},$$slots:{default:!0}}))}const H=e=>e;function L(e){const t=e-1;return t*t*t+1}function l(e,t,s){return Number.isNaN(t)?"":`${e}: ${s*t}px;`}function D(e,{delay:t=0,duration:s=400,easing:a=H}={}){const n=+getComputedStyle(e).opacity;return{delay:t,duration:s,easing:a,css:o=>`opacity: ${o*n}`}}function O(e,{delay:t=0,duration:s=400,easing:a=L,axis:n="y"}={}){const o=getComputedStyle(e),r=+o.opacity,i=n==="y"?"height":"width",S=parseFloat(o[i]),c=n==="y"?["top","bottom"]:["left","right"],p=c.map(d=>`${d[0].toUpperCase()}${d.slice(1)}`),N=parseFloat(o[`padding${p[0]}`]),b=parseFloat(o[`padding${p[1]}`]),w=parseFloat(o[`margin${p[0]}`]),P=parseFloat(o[`margin${p[1]}`]),x=parseFloat(o[`border${p[0]}Width`]),A=parseFloat(o[`border${p[1]}Width`]);return{delay:t,duration:s,easing:a,css:d=>`overflow: hidden;opacity: ${Math.min(d*20,1)*r};`+l(i,S,d)+l(`padding-${c[0]}`,N,d)+l(`padding-${c[1]}`,b,d)+l(`margin-${c[0]}`,w,d)+l(`margin-${c[1]}`,P,d)+l(`border-${c[0]}-width`,x,d)+l(`border-${c[1]}-width`,A,d)+`min-${i}: 0`}}const R=e=>{let t=null;const s=M(y),a={role:"system",content:""};if(s){const n=s.find(o=>o.id===e);n&&(t={...n,options:n.options||{},systemPrompt:n.systemPrompt||a})}if(!t){const n=v()[0];t={id:e,model:n,systemPrompt:a,updatedAt:new Date().toISOString(),messages:[],options:{}}}return t},V=e=>{const t=M(y)||[],s=t.findIndex(o=>o.id===e.id);s!==-1?t[s]=e:t.push(e);const a=I(t);y.set(a);const n=v();z.update(o=>({...o,lastUsedModels:n}))};function J(e){const t=[];return e.updatedAt&&t.push(T(e.updatedAt)),e.model&&t.push(e.model.name),t.join(" • ")}function K(e){if(e.title)return e.title;const t=e.messages.find(s=>s.role==="user"&&s.content&&!s.knowledge);return t!=null&&t.content?t.content.slice(0,56):""}function Q(e,t){return`#/${e}/${t||F()}`}export{X as B,Z as M,j as P,k as S,V as a,K as b,D as c,J as f,Q as g,R as l,O as s};
