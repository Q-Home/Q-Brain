import{al as a}from"./BaEqmHSu.js";a();
