import type {
	ChatRequest,
	ChatResponse,
	ErrorResponse,
	ListResponse,
	ProgressResponse,
	PullRequest,
	StatusResponse
} from 'ollama/browser';

import type { Server } from '$lib/connections';
import type { Model } from '$lib/settings';

import type { ChatStrategy } from './index';

export interface OllamaOptions {
	numa: boolean;
	num_ctx: number;
	num_batch: number;
	num_gpu: number;
	main_gpu: number;
	low_vram: boolean;
	f16_kv: boolean;
	// logits_all: boolean; // REF https://github.com/ollama/ollama-js/issues/145
	vocab_only: boolean;
	use_mmap: boolean;
	use_mlock: boolean;
	// embedding_only: boolean; // REF https://github.com/ollama/ollama-js/issues/145
	num_thread: number;

	// Runtime options
	num_keep: number;
	seed: number;
	num_predict: number;
	top_k: number;
	top_p: number;
	min_p: number; // REF https://github.com/ollama/ollama-js/issues/145
	tfs_z: number;
	typical_p: number;
	repeat_last_n: number;
	temperature: number;
	repeat_penalty: number;
	presence_penalty: number;
	frequency_penalty: number;
	mirostat: number;
	mirostat_tau: number;
	mirostat_eta: number;
	penalize_newline: boolean;
	stop: string[];
}

// Q-Brain integration: the authenticated parent proxies fixed chat operations.
function bridge(payload: unknown): Promise<any> {
    const api = (window.parent as any).qbrainChat;
    if (!api) throw new Error('Open de chat vanuit de Q-Brain pluginpagina.');
    return api(payload);
}
export class OllamaStrategy implements ChatStrategy {
    constructor(private server: Server) {}
    async getModels(): Promise<Model[]> {
        const result = await bridge({op:'models'});
        return [{name:result.model,serverId:'qbrain'}];
    }
    async verifyServer(): Promise<boolean> { return true; }
    async pull(): Promise<void> { throw new Error('Beheer het model op de Q-Brain pluginpagina.'); }
    async chat(payload: ChatRequest, abortSignal: AbortSignal, onChunk:(content:string)=>void): Promise<void> {
        if ((payload.messages.at(-1)?.content.length || 0)>1000) throw new Error('Houd je vraag onder 1000 tekens.');
        const messages = payload.messages.filter(m=>m.role==='user'||m.role==='assistant').slice(-6)
            .map(m=>({role:m.role,content:m.content.slice(0,1000)}));
        const job = await bridge({op:'create',messages});
        const cancel = ()=>{bridge({op:'cancel',id:job.id}).catch(()=>{});};
        abortSignal.addEventListener('abort',cancel,{once:true});
        try {
            for (let i=0;i<360;i++) {
                if (abortSignal.aborted) throw new Error('Vraag geannuleerd.');
                const state = await bridge({op:'status',id:job.id});
                if (state.status==='completed') {onChunk(state.answer);return;}
                if (state.status==='failed') throw new Error(state.error);
                if (state.status==='cancelled') throw new Error('Vraag geannuleerd.');
                await new Promise(resolve=>setTimeout(resolve,2000));
            }
            cancel(); throw new Error('De chatvraag duurde te lang.');
        } finally {abortSignal.removeEventListener('abort',cancel);}
    }
}
