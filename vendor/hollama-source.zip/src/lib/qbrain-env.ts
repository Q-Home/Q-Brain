export const env = {PUBLIC_ADAPTER:'qbrain-static'};
