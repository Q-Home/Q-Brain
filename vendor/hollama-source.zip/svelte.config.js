import adapter from '@sveltejs/adapter-static';
import { vitePreprocess } from '@sveltejs/vite-plugin-svelte';
export default {preprocess:[vitePreprocess({})],kit:{adapter:adapter({fallback:'index.html'}),router:{type:'hash'},alias:{$i18n:'src/i18n'}}};
